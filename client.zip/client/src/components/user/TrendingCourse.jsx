import React from 'react'
import SectionTitle from './SectionTitle'
import HorizontalRule from '../common/HorizontalRule'
import CourseCard from './CourseCard'

function TrendingCourse() {
  return (
    <>
    <SectionTitle title='Trending Course' description='View the trending courses in LMS' />
    <HorizontalRule />

    <CourseCard />
    </>
  )
}

export default TrendingCourse