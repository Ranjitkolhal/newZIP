import React, { useState } from 'react';
import axios from 'axios';

function AdminPanel() {
  const [certificateId, setCertificateId] = useState('');
  const [studentName, setStudentName] = useState('');
  const [imageUrl, setImageUrl] = useState('');

  const handleAddCertificate = () => {
    axios.post('http://localhost:3000/api/admin/addCertificate', { certificateId, studentName, imageUrl })
      .then(response => {
        console.log(response.data.message);
        // Clear the form or show a success message
      })
      .catch(error => {
        console.error(error);
        // Handle error, show an error message, etc.
      });
  }

  return (
    <div>
      <h2>Admin Panel</h2>
      <form>
        <input
          type="text"
          placeholder="Certificate ID"
          value={certificateId}
          onChange={(e) => setCertificateId(e.target.value)}
        />
        <input
          type="text"
          placeholder="Student Name"
          value={studentName}
          onChange={(e) => setStudentName(e.target.value)}
        />
        <input
          type="text"
          placeholder="Image URL"
          value={imageUrl}
          onChange={(e) => setImageUrl(e.target.value)}
        />
        <button type="button" onClick={handleAddCertificate}>Add Certificate</button>
      </form>
    </div>
  );
}

export default AdminPanel;
