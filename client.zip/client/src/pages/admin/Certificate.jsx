import React, { Component } from 'react';
import './certificate.css'
import DefaultLayout from '../../components/admin/DefaultLayout'

import app from '../../config/firebase';
import {
  getStorage,
  ref,
  uploadBytes,
  getDownloadURL,
} from 'firebase/storage';
import {
  getDatabase,
  ref as dbRef,
  update,
  onValue, // Import onValue from the Firebase database module
} from 'firebase/database';

class Certificate extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: '',
      certificateId: '',
      image: null,
      imageUrl: '',
      certificates: [],
      searchQuery: '',
      uploadSuccess: false,
    };
  }

  componentDidMount() {
    const database = getDatabase(app);
    const databaseRef = dbRef(database, 'certificates');

    onValue(databaseRef, (snapshot) => {
      const data = snapshot.val() || [];
      const certificates = Object.values(data);
      this.setState({ certificates });
    });
  }

  handleInputChange = (event) => {
    this.setState({ [event.target.name]: event.target.value });
  };

  handleImageUpload = (event) => {
    const image = event.target.files[0];
    this.setState({ image });
  
    const storage = getStorage(app);
    const certificateId = this.state.certificateId;
    const imageExtension = image.name.split('.').pop(); // Get the file extension
    const imageFileName = this.state.name + '.' + imageExtension; // Construct the image file name
  
    if (certificateId.length === 5) {
      const storageRef = ref(storage, 'gs://lmsfinal-ranjit.appspot.com/' + imageFileName);
  
      uploadBytes(storageRef, image).then(() => {
        getDownloadURL(storageRef).then((imageUrl) => {
          const { name } = this.state;
  
          const newCertificate = {
            name,
            certificateId,
            imageUrl,
          };
  
          const database = getDatabase(app);
  
          const specificCertificateRef = dbRef(database, 'certificates/' + certificateId);
  
          update(specificCertificateRef, newCertificate).then(() => {
            this.setState({
              name: '',
              certificateId: '',
              image: null,
              imageUrl,
              uploadSuccess: true,
            });
          });
        });
      });
    } else {
      // Handle invalid certificateId
      console.error('Invalid certificateId. It should be 5 digits.');
    }
  };
  
  

  handleSearch = (event) => {
    this.setState({ searchQuery: event.target.value });
  };

  render() {
    const { name, certificateId, certificates, searchQuery, uploadSuccess } = this.state;
    const filteredCertificates = certificates.filter((certificate) =>
      certificate.name.toLowerCase().includes(searchQuery.toLowerCase())
    );

    return (
      <DefaultLayout>

        <div  className="certcontainer">

      <div>
        <div>
          <h2>Add Certificate</h2>
          <input
            type="text"
            name="name"
            placeholder="Name"
            value={name}
            onChange={this.handleInputChange}
          />
          <input
            type="text"
            name="certificateId"
            placeholder="Certificate ID"
            value={certificateId}
            onChange={this.handleInputChange}
          />
          <input type="file" onChange={this.handleImageUpload} />
          {uploadSuccess && <p>Uploaded Successfully!</p>}
          <button className='certbtn' onClick={this.handleUploadCertificate}>Upload Certificate</button>
        </div>
        <br />
        <br />
        <br />
        <br />
        <h1>Certificate Management</h1>
        <input
          type="text"
          placeholder="Search Certificates"
          onChange={this.handleSearch}
        />
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Certificate ID</th>
              <th>Image</th>
            </tr>
          </thead>
          <tbody>
            {filteredCertificates.map((certificate, index) => (
              <tr key={index}>
                <td>{certificate.name}</td>
                <td>{certificate.certificateId}</td>
                <td>
                  <img className='cerimg' src={certificate.imageUrl} alt="Certificate" />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      </div>
      </DefaultLayout>

    );
  }
}

export default Certificate;
