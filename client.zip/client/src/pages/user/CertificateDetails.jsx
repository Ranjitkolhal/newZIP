import React, { useState, useEffect } from 'react';
import app from '../../config/firebase';
import './certificate.css'
import {
  getDatabase,
  ref as dbRef,
  get,
} from 'firebase/database';
import { useParams } from 'react-router-dom';

function CertificateDetail() {
  const { certificateId } = useParams();
  const [certificate, setCertificate] = useState(null);
function    handleDownloadCertificate (){
    const imageUrl = certificate.imageUrl;
    const link = document.createElement('a');
    link.href = imageUrl;
    link.target = '_blank'; // Open in a new tab/window
    link.download = imageUrl; // Set the desired filename
    link.style.display = 'none'; // Hide the link
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  useEffect(() => {
    const database = getDatabase(app);
    const certificateRef = dbRef(database, `certificates/${certificateId}`);

    get(certificateRef)
      .then((snapshot) => {
        if (snapshot.exists()) {
          setCertificate(snapshot.val());
        } else {
          console.error('Certificate not found or invalid.');
        }
      })
      .catch((error) => {
        console.error('Error loading certificate:', error);
      });
  }, [certificateId]);

  if (certificate) {
    return (
      <div>
        <h1 className='pop-heading'>Certificate Detail</h1>
        <div style={{width : "400px", margin : "auto", backgroundColor: "#fff", textAlign : "center", padding : "30px", borderRadius : "5px"}}>
        <p className='pop-name'>Name: {certificate.name}</p>
        <p className='pop-id'>Certificate ID: {certificate.certificateId}</p>
        <img className='pop-img' src={certificate.imageUrl} alt="Certificate" />
        <button className="download-button" onClick={handleDownloadCertificate}>
              Download Certificate
            </button>
        </div>
      </div>
    );
  } else {
    return <p className='not-found-error'>Certificate not found or invalid.</p>;
  }
}

export default CertificateDetail;
