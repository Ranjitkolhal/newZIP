import React, { Component } from 'react';
import app from '../../config/firebase';
import { getDatabase, ref, child, get } from 'firebase/database';

class UserCertificate extends Component {
  constructor(props) {
    super(props);
    this.state = {
      certificateId: '',
      certificateData: null,
      verificationResult: null,
    };
  }

  handleCertificateIdChange = (event) => {
    this.setState({ certificateId: event.target.value });
  };

  handleVerifyCertificate = async () => {
    const certificateId = this.state.certificateId;

    // Reference to the Firebase database
    const database = getDatabase(app);
    const certificateRef = ref(database, `certificates/${certificateId}`);

    try {
      // Fetch certificate data
      const snapshot = await get(certificateRef);
      const certificateData = snapshot.val();

      if (certificateData) {
        this.setState({
          certificateData,
          verificationResult: 'Certificate is valid!',
        });
      } else {
        this.setState({
          certificateData: null,
          verificationResult: 'Certificate not found',
        });
      }
    } catch (error) {
      console.error('Error verifying certificate:', error);
      this.setState({
        certificateData: null,
        verificationResult: 'Error verifying certificate',
      });
    }
  };

  render() {
    const { certificateId, certificateData, verificationResult } = this.state;

    return (
      <div>
        <h1>Verify Certificate</h1>
        <input
          type="text"
          placeholder="Enter Certificate ID"
          value={certificateId}
          onChange={this.handleCertificateIdChange}
        />
        <button onClick={this.handleVerifyCertificate}>Verify Certificate</button>

        {verificationResult && <p>{verificationResult}</p>}

        {certificateData && (
          <div>
            <h2>Certificate Details</h2>
            <p>Name: {certificateData.name}</p>
            <p>Certificate ID: {certificateData.certificateId}</p>
            <p>Image URL: {certificateData.imageUrl}</p>
          </div>
        )}
      </div>
    );
  }
}

export default UserCertificate;
