import React, { Component } from 'react';
import app from '../../config/firebase'; // Import your Firebase configuration
import { getDatabase, ref, get } from 'firebase/database';
import './certificate.css'


class GetCertificate extends Component {
    constructor(props) {
      super(props);
      this.state = {
        certificateId: '', // Input field for certificate ID
        certificateData: null, // Certificate data fetched from Firebase
        showModal: false, // Show or hide the popup
      };
    }
  
    handleCertificateIdChange = (event) => {
      this.setState({ certificateId: event.target.value });
    };
  
    handleFetchCertificate = async () => {
      const { certificateId } = this.state;
  
      if (certificateId.trim() === '') {
        return; // Don't fetch if certificateId is empty
      }
  
      const database = getDatabase(app);
      const certificateRef = ref(database, `certificates/${certificateId}`);
  
      try {
        const snapshot = await get(certificateRef);
        const certificateData = snapshot.val();
  
        if (certificateData) {
          this.setState({ certificateData, showModal: true });
        } else {
          console.error('Certificate not found');
        }
      } catch (error) {
        console.error('Error fetching certificate:', error);
      }
    };
  
    handleCloseModal = () => {
      this.setState({ showModal: false });
    };
    handleDownloadCertificate = () => {
      const imageUrl = this.state.certificateData.imageUrl;
      const link = document.createElement('a');
      link.href = imageUrl;
      link.target = '_blank'; // Open in a new tab/window
      link.download = imageUrl; // Set the desired filename
      link.style.display = 'none'; // Hide the link
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    };
    
    
    render() {
      const { certificateId, certificateData, showModal } = this.state;
  
      return (
        <div style={{display :"flex", flexDirection : "column", alignItems : "center", justifyContent:"center"}}> 
          <h1 style={{fontSize :"25px", margin:'30px'}}>Verify Certificate</h1>
          <input 
            type="text" style={{width : '300px'}}
            placeholder="Certificate ID"
            value={certificateId}
            onChange={this.handleCertificateIdChange}
          />
          <button className='download-button' onClick={this.handleFetchCertificate}>Verify Certificate</button>
  
          {showModal && certificateData && (
            <div className="modal">
              <div className="modal-content">
                <button onClick={this.handleCloseModal} className="close-button">
                  X
                </button>
                <h2 className="pop-heading">Certificate Details</h2>
                <p className="pop-name">Name: {certificateData.name}</p>
                <p className="pop-id">Certificate ID: {certificateData.certificateId}</p>
                <img className="pop-img" src={certificateData.imageUrl} alt="Certificate" />
                <button className="download-button" onClick={this.handleDownloadCertificate}>
              Download Certificate
            </button>
              </div>
            </div>
          )}
        </div>
      );
    }
  }
  
  export default GetCertificate;
  